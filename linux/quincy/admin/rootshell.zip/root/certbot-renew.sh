certbot renew --cert-name maqiangcgq.com --manual-auth-hook /root/callAliyun.sh 
